library("dplyr")
library("Rfast")
library("ggplot2")
library("progress")
library("matrixStats")
library("tidyr")

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


# d18O measured data (combined file for all teeth)

seq <- read.csv("data/LAB69.csv", sep=";") 
    #LLAMAR AL ARCHIVO DE ORIGEN DE LOS DATOS (EN DATA), ESTAR ATENTA A SEPARADORES, EN EL ORIGINAL ES ";"
    #En el script original este comando es: #seq <- read.csv("data/example_tooth_isotope_data.csv") 

#Detectando errores con Marco:  head(seq)  ///  seq$Tooth.ID

#make list of all teeth from this file

# individual models
# tlist <- c("tooth1", "tooth2", "tooth3")
# once all models have been run

tlist <- as.vector(unique(seq$Tooth.ID))


#make filenames

passeyfiles = paste("output/LAB69_fraser_inverse_model_output.csv", sep = ",")
    #LLAMAR DE NUEVO AL ARCHIVO DE OUTPUT - ESTAR ATENTA A SEPARADORES, EN EL GENERADO ES ","

#read all files into list
passey.ls <- lapply(passeyfiles, read.csv)
#add column with Tooth ID to each list element
passey.ls.id <- mapply(cbind, passey.ls, "Tooth"=tlist, SIMPLIFY=F)

# add measured d18O data and dist ERJ

#rbind list into a dataframe
passey.data <- do.call(rbind, passey.ls.id) 

#remove unnecessary columns
passey.data <- passey.data %>%
  select(Tooth, dMeas, ci.length, lower.CI, upper.CI, mean)
    #ojo he quitado una d a "dMeasd", ha quedado en "dMeas"

# now read in d18O measured data with dist ERJ
# crop ci.length as in modelling script, add measured isotope/distERJ data to data frame
# then do all the fun plotting

head(seq)

seq <- seq %>%
  mutate(Tooth = Tooth.ID)

layers <- seq %>%
  select(Tooth, Layer) %>%
 distinct()


#### cropping

# extract length of dataframe for each tooth

mslength <- seq %>%
  group_by(Tooth) %>%
  summarise(n = n())

#empty object
pscrop <- NULL

# loop over teeth to crop to mslength
for (i in tlist) {
  pc <- passey.data %>%
    filter(Tooth == i) %>%
    filter(ci.length < max(seq$dist.ERJ[seq$Tooth == i], na.rm = T)+3)
  pscrop <- rbind(pscrop, pc)
  }

psall <- left_join(pscrop, layers)

# write cropped output of all teeth combined to csv
write.csv(psall, file = "output/LAB69_fraser_inverse_model_out_all.csv")

# read the csv of all specimen model outputs
psall <- read.csv("output/LAB69_fraser_inverse_model_out_all.csv")

ylab.name.o <- expression("Enamel "*delta^18*'O (\u2030 VPDB)' )

plotcolor <- "#51B2C3"

model_plot <- ggplot(psall, aes(x = ci.length, y = dMeas))+
  theme_classic()+
  theme(legend.position = "bottom", strip.background = element_rect(colour = "white", fill = "grey95", size = 1), 
        panel.background=element_blank(), 
        panel.border=element_rect(colour="grey95",size = 0.1, fill = NA), 
        axis.text = element_text(size = 12), 
        axis.title = element_text(size = 14), 
        strip.text = element_text(size = 12))+
  ylab(ylab.name.o)+
  xlab("model total length (mm)")+
  xlim(60,0)+
  geom_ribbon(aes(x = ci.length, ymin = lower.CI, ymax = upper.CI, linetype = "solid"), fill = "lightgrey", alpha = 0.7)+
  geom_line(aes(x = ci.length, y = mean, linetype = "solid"), lwd = 1, colour = "grey")+
  scale_linetype_manual(name = "estimated input", values = c("solid"),labels = c(""))+
  # geom_line(aes(x = ci.length, y = dMeas, colour = ""), lwd = 2)+
  # geom_point(size = 4, aes(x = ci.length, y = dMeas, fill = ""), colour = "black", shape = 21)+
  geom_line(data = seq, aes(x = dist.ERJ, y = mean.d18O, colour = ""), lwd = 2)+
  geom_point(data = seq, size = 4, aes(x = dist.ERJ, y = mean.d18O, fill = ""), colour = "black", shape = 21)+
  labs(fill = expression('measured '*italic(delta)^18*'O  '), colour = expression('measured '*italic(delta)^18*'O  '))+
  scale_color_manual(values = plotcolor)+
  scale_fill_manual(values = plotcolor)+
  guides(fill = guide_legend(order = 1, override.aes=list(shape=21)))+
  guides(colour = guide_legend(order = 1))+
  #scale_y_continuous(n.breaks = 12)+
  #annotate("text", label = tooth.name, x = 60, y = 28, hjust = 0)+
  facet_wrap(. ~ Tooth)
#+ NULL

model_plot

ggsave("output/LAB69_fraser_inverse_model_all_plot.png", plot = model_plot, device = "png", dpi = 300, width = 4.5, height = 3.5)



