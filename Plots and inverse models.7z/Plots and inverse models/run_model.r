
# Running the passey models
# load libraries

library("matrixcalc")
library("dplyr")
library("ggplot2")

# working directory should be set to source file location
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


#### load functions from external script ####

source("functions/Fraser_2021_inverse_model_mSolv1.r")
source("functions/Pederzani_Emeas_translation.R")


# specify project name for model reports

projectname <- "Passey model - LAB69" 

tooth.name <- "LAB69"


# read data input for tooth

tooth.data <- read.csv("data/LAB69.csv",sep=";")

tooth.data


#### running the Emeas function ####

  ## input variables:
    # numtrials - number of trials to run iteration
    # numsam - number of isotope samples/values
    # length - distance between each sample and the next sample in mm*10, occlusal sample to go first
    # dMeas - d18O values, occlusal sample to go first
    # r1 - (real) isotope 1 sigma reproducibility
    # r2 - (integer) sample length 1 sigma reproducibility (in mm * 10)
    # r3 - (integer) sample depth 1-sigma reproducibility (in mm * 10)
    # la - (integer) length of apposition (in mm * 10) --> get species specific data from literature

numtrials <- 50 # define number of model solutions

#### define some empty objects ####
Edist <- rep(0,numtrials)
allTrials <- rep(0,numtrials)


r1 <- 0.12 
r2 <- 1  
r3 <- 2    
la <- 15

## run the Emeas function to generate Emeas estimates

tooth.data <- tooth.data %>% mutate(Passey.length = length.raw*10) # transform sample length data into 10*mm units for model input

Emeasout <- Emeasfun(numtrials = numtrials, numsam = length(tooth.data$mean.d18O), length = tooth.data$Passey.length, 
                     dMeas = round(tooth.data$mean.d18O, 1), r1 = r1, r2 = r2, r3 = r3, la = la)
      
Emeas.params <- list(numtrials = numtrials, r1 = r1, r2 = r2, r3 = r3, la = la)


ggplot(Emeasout, aes(x = totallength, y = allTrials))+
  theme_classic()+
  xlim(500,0)+
  geom_line()+
  geom_point(shape = 3)+
  geom_point(aes(x = totallength, y = dMeas), colour = "black", shape = 0)+
  geom_line(aes(x = totallength, y = dMeas), colour = "black")+
  geom_line(aes(x = totallength, y = dMeasError), colour = "black")+
  geom_point(aes(x = totallength, y = dMeasError), colour = "black", shape = 1)


#### evaluate Emeas to adjust df in mSolv code ####
# the distribution of Emeas values is stored in an object called 'Edist'
# values of Emeas/Edist should be close to DPE values from mSolv code
# adjust df stepwise to match Emeas/Edist to DPE

hist(Edist)
mean.edist <- mean(Edist)
mean.edist


#### running the mSolv1_1 function ######

#### input parameters ####

nsolxns <- 100 # number of solutions to be computed
r1 = 0.12; 
r2 = 1; 
r3 = 2; 
dMeas <- round(tooth.data$mean.d18O, 1)# isotope data input
openindx <- 1 # degree of open-endedness, less than lm, openended (profile mature) --> index = 1; 
# close ended (enamel immature) index = lm
Length <- tooth.data$Passey.length # length in mm*10
avelength <- round(mean(tooth.data$length.raw)*10, digits = 0) # average sample length
la <-  15 # length of apposition in mm*10 -> Bos/Bison= 15 (1.5*10); Equus= 60 (6*10)
lm <- 250 # length of maturation in mm*10-> Bos/Bison= 250 (25*10); Equus= 280 (28*10)
lamm <- la/10 #length of apposition in mm
finit <- 0.25# initial mineral %weight -> Bos/Bison= 0.25 (25%); Equus= 0.22 (22%)
enamel_thickness_mm <- 1.5 # enamel thickness in mm of your tooth specimen
sample_depth_fraction <- tooth.data$depth/enamel_thickness_mm
depth <- round(tooth.data$depth*lamm, 1)*10


# some derived numbers used during modelling

numbefore=ceiling(la/avelength)
numafter=ceiling((lm-openindx)/avelength)+1 
DPE = rep(0,nsolxns) # empty object for DPE to enable writing to global env from inside function


# input parameters of the reference vector
numsam <- length(dMeas) # calculates automatically
maxlength <- 30 # maximum sample length in data (mm * 10)
minlength <- 10 # minimum sample length in data (mm * 10)
mindepth <- 5 # minimum sample depth in data (mm * 10) 

#Adjust how flat or how strength can be the model
mean(tooth.data$mean.d18O) #Use the mean just to establish the max and the min ratio
maxratio = -6.5;  # maxratio - max value for reference vector
minratio = -8; # minratio - min value of reference vector 
stdev = .5; # stdev - sd for random draws that produce reference vector (0.5 = 95%) 
df = 0.005# damping factor (recommend to start in 0.001)



## after adjusting df, the model needs to be tested for sensitivity to the reference vector
## --> check whether more oscillating (max and min further apart) generates drastically different solution
# df - damping factor. Needs to be chosen to minimize difference between the estimated measurement error
# (E~meas~) and the prediction error (E~pred~)



# write parameter input into a list for printing the model report

mSolvparams <- list(nsolxns = nsolxns, openindx = openindx, lm = lm, la = la, finit = finit, maxlength = maxlength, minlength = minlength, 
                    mindepth = mindepth,r1 = r1, r2 = r2, r3 = r3, maxratio = maxratio, minratio = minratio, stdev = stdev, df = df)

### run mSolv function ###

lfsolv <- PasseyInverse(Length = Length,dMeas = dMeas,depth = depth,la = la,lm = lm, maxlength = maxlength, minlength = minlength, 
                      mindepth = mindepth, df = df, nsolxns = nsolxns, finit = finit, openindx = openindx, avelength = avelength, 
                      r1 = r1, r2 = 2, r3 = r3, maxratio = maxratio, minratio = minratio, stdev = stdev, numsam = numsam)

# plot some example solutions of mSolv

ggplot(solvout, aes(x = totallength, y = dMeas))+
  theme_classic()+
  geom_point(colour = "black")+
  geom_line(colour = "black")+
  geom_line(aes(x = totallength, y = trial1), colour = "lightblue")+
  geom_line(aes(x = totallength, y = trial2), colour = "lightblue")+
  geom_line(aes(x = totallength, y = trial3), colour = "lightblue")+
  geom_line(aes(x = totallength, y = trial4), colour = "lightblue")+
  geom_line(aes(x = totallength, y = trial5), colour = "lightblue")+
  geom_line(aes(x = totallength, y = trial6), colour = "lightblue")+
  geom_line(aes(x = totallength, y = trial7), colour = "lightblue")+
  geom_line(aes(x = totallength, y = trial8), colour = "lightblue")+
  geom_line(aes(x = totallength, y = trial9), colour = "lightblue")+
  geom_line(aes(x = totallength, y = trial10), colour = "lightblue")



#### evaluate DPE (= Epred, prediction error) vs Edist (= Emeas, estimated measurement error) ####

# DPE should be close to Edist
# adjust df to achieve this
# increase df to increase DPE


#Histogram predicted error (DPE) that will show where the mean of the error falls

hist(DPE, breaks = 10) 

mean(DPE)
# compare to measurement error calculated in the first part of the model
mean.edist


#### Generate report of model parameters ####


rmarkdown::render("make_model_report.Rmd", params = list(
  project = projectname, 
  tooth = tooth.name, 
  Emeasparams = Emeas.params, 
  Edist = Edist, 
  mSolvparams = mSolvparams, 
  DPE = DPE
), output_file = paste0("output/",tooth.name, "_fraser_inverse_model_report.html"))



#### extract output with mean and CI and write to csv ####

# extract only trial ouput

tdata <- solvout %>%
  select(-totallength)

tdatatrans <- t(tdata)
tdatatrans

nl <- 1:(numsam+numbefore+numafter-1)

lengths <- paste("l",nl,sep="")

colnames(tdatatrans) <- lengths

# calculate mean and confidence interval (95%)

tdata_lci <- apply(tdatatrans,MARGIN=2,quantile,prob=0.025,na.rm=T) # calculate lower boundary of Conf Interval 
tdata_uci <- apply(tdatatrans,MARGIN=2,quantile,prob=0.975,na.rm=T) # calculate upper boundary of Conf Interval 
tdata_mean <- apply(tdatatrans,MARGIN=2,mean) # calculate mean (essentially the most likely model solution)

# bind into data frame and clean up names
tdataci <- cbind(solvout$totallength,tdata_lci,tdata_uci,tdata_mean)
tdataci
colnames(tdataci) <- c("ci.length","lower.CI","upper.CI","mean")

# convert to data frame
tdataci.d <- as.data.frame(tdataci)

# convert lengths back into mm
tdataci.d$ci.length <- tdataci.d$ci.length/10

# combine all output
all.out <- cbind(solvout, tdataci.d)

all.out <- all.out %>%
  mutate(tooth = tooth.name) %>%
  mutate(Layer = tooth.data$Layer[1])

# write output to csv
outputfile <- paste("output/",tooth.name, "_fraser_inverse_model_output.csv", sep = "")
write.csv(all.out, file = outputfile)

