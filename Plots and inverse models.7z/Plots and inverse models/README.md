# 18O_and_13C_enamel-carbonate
