
# load libraries

library(tidyverse)

# read in Passey model data

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


# read data input for tooth

psall <- read.csv("output/LAB69_fraser_inverse_model_out_all.csv",sep=",")


head(psall)

#### extract seasonal peak and trough ####


# isolate sinusoid one year interval

# make dataframe with limits to scan for the maximum and minimum


limits <- data.frame(Tooth = unique(psall$Tooth), 
                     summer_begin = c(10), 
                     summer_end = c(35),
                     winter_begin = c(25), 
                     winter_end = c(40))

# extract winter

winter_out <- NULL

for (i in limits$Tooth) {
  out <- psall %>%
    filter(Tooth == i) %>%
    filter(ci.length < limits$winter_end[limits$Tooth==i] & ci.length > limits$winter_begin[limits$Tooth==i]) %>%
    select(Tooth, Layer, ci.length, lower.CI, upper.CI, mean)%>%
    filter(mean == min(mean)) %>%
    mutate(Extremum = "Winter")
  
  winter_out <- rbind(winter_out, out)
  
}

# extract summer

summer_out <- NULL

for (i in limits$Tooth) {
  out <- psall %>%
    filter(Tooth == i) %>%
    filter(ci.length < limits$summer_end[limits$Tooth==i] & ci.length > limits$summer_begin[limits$Tooth==i]) %>%
    select(Tooth, Layer, ci.length, lower.CI, upper.CI, mean)%>%
    filter(mean == max(mean)) %>%
    mutate(Extremum = "Summer")
  
  summer_out <- rbind(summer_out, out)
  
}

extrema.out <- rbind(winter_out, summer_out)


write.csv(extrema.out, file = "output/LAB69_fraser_inverse_model_output_extrema.csv")

