
#install.packages("")

library(ggplot2) 
library(openxlsx)
library(gridExtra)

# open working directory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


# read data input for tooth

dataset <- read.csv("data/LAB69.csv",sep=";") 


#Put names for titles

tooth.name <- dataset$Tooth.ID
dataset
tooth.type <- "Level V - Bos primigenius - Lower right m3" 


#Do plot including carbon and oxygen isotope compositions 

correction <- 5

intratooth_plot_together_adapt <- ggplot(dataset, aes()) +
  geom_line(aes(x = dist.ERJ,y = mean.d18O), color = "#51B2C3", size=1.5, alpha=0.7)+
  geom_point(data = dataset, size = 6, aes(x = dist.ERJ, y = mean.d18O), shape = 21, colour = "#51B2C3", fill="#51B2C3", alpha=0.7)+
  geom_line(aes(x = dist.ERJ,y = mean.d13C+correction), colour = "#CC6633", size=1.5, alpha=0.7)+
  geom_point(data = dataset, size = 6, aes(x = dist.ERJ, y = mean.d13C+correction), shape = 21, colour = "#CC6633", fill="#CC6633", alpha=0.7)+
  scale_y_continuous(sec.axis=sec_axis(~.-correction,name=(expression(paste(delta^{13}, "C  V-PDB (\u2030)"))),breaks=seq(-13,-8,1),),limits=c(-8,-3))+
  xlim(60,0)+
  facet_grid()+
  theme(
    strip.text = element_text(size = 12,),
    plot.title = element_text(hjust = 0.5,size = 15, face="bold"),
    plot.subtitle = element_text(hjust = 0.5,size = 12, face="bold"),
    axis.text = element_text(size = 14),
    axis.title = element_text(size = 14, face="bold"))+
  ylab(expression(paste(delta^{18}, "O  V-PDB (\u2030)"))) +
  xlab(expression(paste("Distance ERJ (mm)")))+
  labs(title=tooth.name, subtitle = tooth.type)

intratooth_plot_together_adapt 
  

ggsave("original/LAB69_intratooh", plot = intratooth_plot_together_adapt, device = "png", dpi = 300, width = 7, height = 5)



    

